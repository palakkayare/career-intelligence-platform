from django.contrib import admin
from django.utils.html import format_html

from .models import Plan, Subscription, PaymentTransaction, WebhookEvent
from .webhook_handlers import process_event


@admin.register(Plan)
class PlanAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'tier', 'billing_period', 'price_inr', 'is_active', 'sort_order')
    list_filter = ('tier', 'billing_period', 'is_active')
    search_fields = ('name', 'slug')


@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ('user', 'plan', 'status', 'current_period_end', 'trial_ends_at', 'created_at')
    list_filter = ('status', 'plan__tier')
    search_fields = ('user__email',)
    raw_id_fields = ('user', 'plan')


@admin.register(PaymentTransaction)
class PaymentTransactionAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'plan', 'amount_inr', 'status', 'razorpay_order_id', 'created_at')
    list_filter = ('status',)
    search_fields = ('user__email', 'razorpay_order_id', 'razorpay_payment_id')
    raw_id_fields = ('user', 'plan', 'subscription')


@admin.register(WebhookEvent)
class WebhookEventAdmin(admin.ModelAdmin):
    list_display = (
        'razorpay_event_id', 'event_type', 'processing_status',
        'retry_count', 'received_at', 'processed_at',
    )
    list_filter = ('event_type', 'processing_status')
    search_fields = ('razorpay_event_id',)
    readonly_fields = ('formatted_payload', 'received_at', 'processed_at')
    exclude = ('payload',)
    actions = ['retry_processing']

    def formatted_payload(self, obj):
        import json
        pretty = json.dumps(obj.payload, indent=2)
        return format_html('<pre>{}</pre>', pretty)
    formatted_payload.short_description = 'Payload'

    @admin.action(description='Retry processing selected events')
    def retry_processing(self, request, queryset):
        success_count = 0
        fail_count = 0
        for event in queryset:
            try:
                process_event(event)
                event.processing_status = WebhookEvent.ProcessingStatus.PROCESSED
                from django.utils import timezone
                event.processed_at = timezone.now()
                event.error_message = ''
                event.save()
                success_count += 1
            except Exception as e:
                event.processing_status = WebhookEvent.ProcessingStatus.FAILED
                event.error_message = str(e)[:1000]
                event.save()
                fail_count += 1

        self.message_user(
            request,
            f"Retried {queryset.count()} events: {success_count} succeeded, {fail_count} failed.",
        )